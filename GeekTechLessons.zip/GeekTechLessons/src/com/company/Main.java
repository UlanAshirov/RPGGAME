package com.company;

public class Main {

    public static void main(String[] args) {
        final int num = 4;
        int num2 = 5;
        //System.out.println(num + "+" + num2);

        int num3;
        num3 = 4;

        //System.out.println(num);

        double doubleNum = 1.34;
        float floutNUm = 1.34f;

        char symbol = '2';

        String word = "hello world";
        word += 20;
        //System.out.println(word);

        //Условные выражения

        if (num > num2) {
            System.out.println("num");

        } else {
            System.out.println("num2");

        }
        for (int i = 0; i <= 10; i++) {
            System.out.println(i);

        }

        while (num < 20) {
            System.out.println("p" + num);
        }



    }
}
